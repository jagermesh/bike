<?php

br()->response()->redirect('index.html');