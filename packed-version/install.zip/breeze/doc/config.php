<?php

br()->request()->setFrameworkUrl(dirname(br()->request()->baseUrl()) . '/');