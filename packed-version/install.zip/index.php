<?php

require_once(__DIR__ . '/vendor/jagermesh/bright/Bright.php');
