<?php

br()->response()->redirect('lib/index.html');