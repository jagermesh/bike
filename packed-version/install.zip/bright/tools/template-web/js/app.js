$(document).ready(function() {

  br.
    request.
      route('/', function() {
      }).
  ;
  
});
