$(document).ready(function() {

  var grid = br.dataBrowser('users', {noun: 'user'});
  grid.refresh();

});