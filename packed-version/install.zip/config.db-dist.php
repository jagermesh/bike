<?php

// Database connection
// br()
//   ->config()
//     ->set( 'db'
//          , array( 'engine'   => 'mysql'
//                 , 'hostname' => 'localhost'
//                 , 'name'     => '[dbname]' 
//                 , 'username' => '[dbuser]'
//                 , 'password' => '[dbpassword]'
//                 , 'charset'  => 'utf8'
//                 ));
